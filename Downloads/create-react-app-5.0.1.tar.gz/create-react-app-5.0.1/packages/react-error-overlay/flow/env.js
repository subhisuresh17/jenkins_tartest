declare module 'anser' {
  declare module.exports: any;
}

declare module '@babel/code-frame' {
  declare module.exports: any;
}

declare module 'html-entities' {
  declare module.exports: any;
}

declare module 'settle-promise' {
  declare module.exports: any;
}

declare module 'source-map' {
  declare module.exports: any;
}
